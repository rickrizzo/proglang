# Programming Languages
## Assignment 1

## Robert Russo and Robert Rotering

## Features
This program features a beta reduction that implements eta reduction to simplify intermediary steps.

## Bugs
I am fairly certain alpha renaming is not exhaustive, some expressions do not totally match, even though they do not appear in the results.

## Notes
Instead of changing letter names for alpha renaming, I appended a '1' character.
