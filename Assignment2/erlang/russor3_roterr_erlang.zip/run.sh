#!/bin/bash

erl -compile main
erl -pa ./main.erl -run main -run init stop -noshell
